OGSR Android — direct Download access, no automatic file copying

What this patch does:
- The engine starts in /storage/emulated/0/Download/OGSR when it finds
  fsgame.ltx there. It reads the game data directly from that directory.
- It accepts /storage/emulated/0/Download/fsgame.ltx as a fallback layout.
- push_data.ps1 installs ONLY the APK. It no longer creates folders or runs
  adb push, so it does not copy game files to the phone.
- stage_data.sh is intentionally not included in this patch; it is only a
  local staging helper and is not needed to run the game from Download.

Expected layout:
  /storage/emulated/0/Download/OGSR/fsgame.ltx
  /storage/emulated/0/Download/OGSR/gamedata/
  /storage/emulated/0/Download/OGSR/*.db
  /storage/emulated/0/Download/OGSR/args.txt (optional)

Important:
- Put/extract the game files into Download/OGSR yourself, once.
- On Android 11+, enable Settings > Apps > OGSR > Special app access >
  All files access. The manifest declares MANAGE_EXTERNAL_STORAGE, but
  Android still requires the user to grant it.
- This is direct file access, not a copy-on-launch mechanism. The engine
  reads files in place. It may still create its own logs/settings in the
  selected game directory, depending on the engine's existing behavior.
- The APK build and real-device access on Android 16 still need testing.

Copy the included files into matching paths in the repository, replacing
existing files, then rebuild the APK.

App name and icon:
- The launcher label is now "S.T.A.L.K.E.R OGSR2".
- A custom OGSR2 launcher icon is included under ogsr_engine/android/res/.
- package_apk.sh compiles and embeds the icon resources during APK packaging.
- The Android application ID remains com.ogsr.online, so an update can replace
  the existing build without changing its package identity.

Updated launcher icon: OGSE-inspired rust-orange radiation emblem, skull and crossed rifles, with OGSR2 lettering. Rebuild the APK to apply it.
